
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Métodos de pagamento</title>
</head>
<body>
    <h1>Métodos de pagamento</h1>
    <h3></h3>
    <table>
        <tr>
            <th>tPag</th>
            <th>Descrição</th>
        </tr>
        <tr>
            <td>01</td>
            <td>Dinheiro</td>
        </tr>
        <tr>
            <td>02</td>
            <td>Cartão de Crédito</td>
        </tr>
        <tr>
            <td>03</td>
            <td>Cartão de Débito</td>
        </tr>
        <tr>
            <td>04</td>
            <td>Boleto Bancário</td>
        </tr>
        <tr>
            <td>05</td>
            <td>Pagamento Instantâneo PIX</td>  
        </tr>
    </table>
</body>
</html>