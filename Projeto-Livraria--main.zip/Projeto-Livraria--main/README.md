Ana Jéssica Pereira Santos @anajessi
Matheus Jesus Gama @mathgama1227
Cristiana de souza farias @crisfarias06
Gustavo Leão @gustavogalazo
Makolin Felipe @makolinfelipe




# Projeto-LIVRARIA-

Entidades:  

Produtos 

Compradores 

Vendedores 

Editora 

Autor 

Sinopse 

Genero 

Classificação 

Estoque 

Formatos dos produtos (pdf, forma fisica) 

 

Recursos:  

Compra de Produtos 

Busca de informações 

Comparações de preço 

Avaliações sobre os produtos 

Leitura Online 

Indicações semanais 

Indicações populares 

Mais comprados 

Neste projeto criaremos uma livraria digital onde será possível, ler de maneira gratuita, comprar, avaliar, obter recomendações do livro alvo desejado, além de apostilas didaticas, cadernos, materiais escolares e etc...
 Criaremos um banco de dados onde serão armazenadas todas as informações provenientes do site.
 Neste site tambem será possível catalogar os livro em sua conta nos quais já tenham sido lidos.
 

 
